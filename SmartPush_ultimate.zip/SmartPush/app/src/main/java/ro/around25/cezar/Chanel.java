package ro.around25.cezar;


public class Chanel {
    String name;

    public Chanel(String name) {
        this.name = name;
    }

    public String getName() {
        return  name;
    }
}
