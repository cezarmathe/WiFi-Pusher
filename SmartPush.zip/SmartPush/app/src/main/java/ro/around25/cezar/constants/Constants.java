package ro.around25.cezar.constants;

public class Constants {
    public static final String STORAGE = "preference_storage";
}
